﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CaliburnDockTestApp.ViewModels
{
	public class TestViewModel : ViewModelBase
	{
	}
}

﻿namespace MLibTest.Demos.Views
{
	using System.Windows.Controls;

	/// <summary>
	/// Interaction logic for ColorSelectionView.xaml
	/// </summary>
	public partial class ColorSelectionView : UserControl
	{
		public ColorSelectionView()
		{
			InitializeComponent();
		}
	}
}

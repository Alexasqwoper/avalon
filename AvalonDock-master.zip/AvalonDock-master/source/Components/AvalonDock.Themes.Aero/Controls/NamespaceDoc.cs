namespace AvalonDock.Themes.Controls
{
	/// <summary>This namespace defines the controls specific for this theme in AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}

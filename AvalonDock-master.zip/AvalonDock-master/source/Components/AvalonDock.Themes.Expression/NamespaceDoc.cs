namespace AvalonDock.Themes
{
	/// <summary>This library defines the Expression theme for AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}

namespace AvalonDock.Controls.Shell
{
	/// <summary>This namespace contains helpers for interaction with the shell (windows OS).</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
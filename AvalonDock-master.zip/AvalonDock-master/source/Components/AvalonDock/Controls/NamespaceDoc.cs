namespace AvalonDock.Controls
{
	/// <summary>This namespace contains the controls needed to visualize the layout tree.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
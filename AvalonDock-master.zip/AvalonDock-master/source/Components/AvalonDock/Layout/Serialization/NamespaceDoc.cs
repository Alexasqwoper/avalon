namespace AvalonDock.Layout.Serialization
{
	/// <summary>All functionality for serialization of a tree can be found here.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
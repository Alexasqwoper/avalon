namespace AvalonDock.Converters
{
	/// <summary>This namespace contains the converters for usage in the WPF controls.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
namespace AvalonDock.Themes
{
	/// <summary>This library defines the Metro theme for AvalonDock.</summary>
	[System.Runtime.CompilerServices.CompilerGenerated]
	internal class NamespaceDoc
	{
	}
}
